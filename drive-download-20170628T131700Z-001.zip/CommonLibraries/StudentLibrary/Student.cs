﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentLibrary
{
    public class Student
    {
        public string Name;
        public string Phone;
        public string Address;
        public bool IsHappy;
        public int? Age;
    }
}