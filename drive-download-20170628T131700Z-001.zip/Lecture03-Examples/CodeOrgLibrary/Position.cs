﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeOrgLibrary
{
    public class Position
    {
        public double X;
        public double Y;
        public double Orientation;
    }
}